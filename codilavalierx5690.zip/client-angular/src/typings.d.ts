/* SystemJS module definition */

//jQuery
declare var jQuery:any;
declare var $:any;

declare var module: NodeModule;
interface NodeModule {
  id: string;
}
