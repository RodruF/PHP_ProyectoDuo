export var GLOBAL = {
	url: 'http://apilaravel.com.devel/api/'
};