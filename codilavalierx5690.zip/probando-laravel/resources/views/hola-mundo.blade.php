@extends('layouts.master')

@section('title', 'Curso Laravel Víctor')

@section('header')
	@parent
	<h1>Cabecera desde hola mundo</h1>
@stop

@section('content')
	<p>Contenido de la vista Hola Mundo</p>
@stop