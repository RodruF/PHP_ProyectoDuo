<h1 style="background:yellow">Esto es la cabecera</h1>
@if(isset($nombre))
<h2>{{$nombre}}</h2>
@endif