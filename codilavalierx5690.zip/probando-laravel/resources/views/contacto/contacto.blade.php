{{-- Mi comentario de HTML --}}
<?php // Mi comentario de HTML ?>

@include('contacto.cabecera', array('nombre' => $nombre))

<h1>Página de contacto {!!$nombre!!} {{-- isset($edad) && !is_null($edad) ? $edad : 'No existe la edad' --}}</h1>

@if(is_null($edad))
	No existe la edad
@else
	Si existe la edad: {{$edad}}
@endif

<p>
	<?php $numero = 6; ?>
Tabla del {{$numero}}
</p>
@for($i = 1; $i <= 10; $i++)
	{{$i.' x '.$numero.' ='.($i*$numero)}}<br/>
@endfor

@include('contacto.cabecera')

<?php $f = 1 ?>
@while($f<=7)
	<p>{{'Hola mundo '.$f}}</p>
	<?php $f++ ?>
@endwhile

<h1>Listado de frutas</h1>
@foreach($frutas as $fruta)
	<p>{{$fruta}}</p>
@endforeach