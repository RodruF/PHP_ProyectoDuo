<h1>{{$note->title}}</h1>
<p>{{$note->description}}</p>
<a href="{{ url('/notas') }}">Volver al listado</a>